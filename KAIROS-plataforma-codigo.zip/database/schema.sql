-- KAIRÓS - PostgreSQL / Supabase-ready schema
-- Execute in a managed PostgreSQL instance and connect the React frontend through an API layer.

create extension if not exists "pgcrypto";

create type user_role as enum ('admin','editor','instructor','visitor','volunteer');
create type content_status as enum ('draft','published','scheduled','archived');
create type alert_severity as enum ('low','moderate','high','critical');

create table profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique,
  full_name text not null,
  email text unique not null,
  role user_role not null default 'visitor',
  avatar_url text,
  municipality text,
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  kind text not null,
  description text,
  created_at timestamptz not null default now()
);

create table pages (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  body jsonb not null default '{}'::jsonb,
  seo jsonb not null default '{}'::jsonb,
  status content_status not null default 'draft',
  author_id uuid references profiles(id),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table media (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  file_name text not null,
  mime_type text not null,
  file_size bigint,
  storage_path text not null,
  alt_text text,
  metadata jsonb not null default '{}'::jsonb,
  uploaded_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  description text,
  category_id uuid references categories(id),
  media_id uuid references media(id),
  document_type text not null,
  tags text[] not null default '{}',
  downloads integer not null default 0,
  status content_status not null default 'draft',
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table protocols (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  hazard_type text not null,
  summary text,
  before_steps jsonb not null default '[]'::jsonb,
  during_steps jsonb not null default '[]'::jsonb,
  after_steps jsonb not null default '[]'::jsonb,
  cover_media_id uuid references media(id),
  status content_status not null default 'draft',
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table protocol_resources (
  protocol_id uuid references protocols(id) on delete cascade,
  media_id uuid references media(id) on delete cascade,
  resource_kind text not null,
  primary key (protocol_id, media_id)
);

create table courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  description text,
  cover_media_id uuid references media(id),
  instructor_id uuid references profiles(id),
  level text,
  duration_minutes integer,
  status content_status not null default 'draft',
  certificate_enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table course_modules (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  title text not null,
  position integer not null,
  description text
);

create table lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references course_modules(id) on delete cascade,
  title text not null,
  content jsonb not null default '{}'::jsonb,
  video_media_id uuid references media(id),
  position integer not null,
  duration_minutes integer not null default 0
);

create table enrollments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  progress numeric(5,2) not null default 0,
  completed_at timestamptz,
  certificate_url text,
  created_at timestamptz not null default now(),
  unique(course_id, user_id)
);

create table evaluations (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  title text not null,
  questions jsonb not null default '[]'::jsonb,
  passing_score numeric(5,2) not null default 70
);

create table news_articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  excerpt text,
  body jsonb not null default '{}'::jsonb,
  category_id uuid references categories(id),
  cover_media_id uuid references media(id),
  author_id uuid references profiles(id),
  status content_status not null default 'draft',
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table alerts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  source text,
  location_name text,
  geometry jsonb,
  severity alert_severity not null,
  status text not null default 'active',
  recommendation text,
  issued_at timestamptz not null,
  expires_at timestamptz,
  external_id text,
  created_at timestamptz not null default now()
);

create table map_layers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  layer_type text not null,
  source_url text,
  style jsonb not null default '{}'::jsonb,
  is_visible boolean not null default true,
  created_at timestamptz not null default now()
);

create table map_points (
  id uuid primary key default gen_random_uuid(),
  layer_id uuid references map_layers(id) on delete cascade,
  name text not null,
  point_type text not null,
  latitude numeric(10,7) not null,
  longitude numeric(10,7) not null,
  details jsonb not null default '{}'::jsonb,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table community_posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid references profiles(id),
  category_id uuid references categories(id),
  title text not null,
  body text not null,
  status content_status not null default 'published',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table comments (
  id uuid primary key default gen_random_uuid(),
  author_id uuid references profiles(id),
  entity_type text not null,
  entity_id uuid not null,
  parent_id uuid references comments(id) on delete cascade,
  body text not null,
  is_approved boolean not null default true,
  created_at timestamptz not null default now()
);

create table favorites (
  user_id uuid references profiles(id) on delete cascade,
  entity_type text not null,
  entity_id uuid not null,
  created_at timestamptz not null default now(),
  primary key (user_id, entity_type, entity_id)
);

create table events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  event_type text not null,
  location_name text,
  starts_at timestamptz not null,
  ends_at timestamptz,
  capacity integer,
  organizer_id uuid references profiles(id),
  status content_status not null default 'published',
  created_at timestamptz not null default now()
);

create table event_registrations (
  event_id uuid references events(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  attendance_status text not null default 'registered',
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);

create table volunteer_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  interest_area text,
  availability text,
  experience text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text,
  request_type text,
  message text not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  title text not null,
  body text,
  notification_type text,
  entity_type text,
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table faq_items (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  position integer not null default 0,
  is_published boolean not null default true
);

create table site_settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references profiles(id),
  updated_at timestamptz not null default now()
);

create index idx_documents_search on documents using gin (to_tsvector('spanish', coalesce(title,'') || ' ' || coalesce(description,'')));
create index idx_news_search on news_articles using gin (to_tsvector('spanish', coalesce(title,'') || ' ' || coalesce(excerpt,'')));
create index idx_posts_search on community_posts using gin (to_tsvector('spanish', coalesce(title,'') || ' ' || coalesce(body,'')));
create index idx_alerts_time on alerts (issued_at desc);
create index idx_map_points_type on map_points (point_type);
