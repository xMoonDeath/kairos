export type Severity = 'Baja' | 'Moderada' | 'Alta' | 'Crítica';
export type UserRole = 'Administrador' | 'Editor' | 'Instructor' | 'Visitante' | 'Voluntario';

export interface ProtocolItem {
  id: string;
  name: string;
  icon: string;
  color: string;
  summary: string;
  before: string[];
  during: string[];
  after: string[];
  downloads: number;
  videos: number;
}

export interface LibraryItem {
  id: string;
  title: string;
  category: string;
  type: 'PDF' | 'Word' | 'Excel' | 'PowerPoint' | 'Imagen' | 'Video';
  size: string;
  updated: string;
  description: string;
  downloads: number;
}

export interface Course {
  id: string;
  title: string;
  category: string;
  description: string;
  duration: string;
  lessons: number;
  level: string;
  progress: number;
  instructor: string;
  modules: string[];
}

export interface NewsItem {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  date: string;
  readTime: string;
  image: string;
}

export interface AlertItem {
  id: string;
  title: string;
  location: string;
  severity: Severity;
  status: 'Activa' | 'En seguimiento' | 'Cerrada';
  issued: string;
  recommendation: string;
}

export interface CommunityPost {
  id: string;
  author: string;
  role: UserRole;
  title: string;
  body: string;
  category: string;
  likes: number;
  comments: number;
  date: string;
}
