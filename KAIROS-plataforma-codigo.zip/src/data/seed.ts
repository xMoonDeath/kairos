import type { AlertItem, CommunityPost, Course, LibraryItem, NewsItem, ProtocolItem } from '../types';

export const protocols: ProtocolItem[] = [
  {
    id: 'inundaciones', name: 'Inundaciones', icon: 'waves', color: '#13a7c7',
    summary: 'Preparación, evacuación segura y recuperación de zonas afectadas por agua y sedimentos.',
    before: ['Identifica rutas altas y puntos seguros.', 'Protege documentos y sustancias peligrosas.', 'Limpia canales y no arrojes residuos a quebradas.', 'Prepara un kit para 72 horas.'],
    during: ['Evita cruzar corrientes o zonas anegadas.', 'Desconecta energía solo si es seguro.', 'Sigue las alertas oficiales y evacúa temprano.', 'Protege niños, mayores y animales.'],
    after: ['No consumas agua sin verificar su calidad.', 'Clasifica lodos, residuos orgánicos y escombros.', 'Documenta daños antes de retirar materiales.', 'Participa en limpieza de cauces con protección.'],
    downloads: 7, videos: 4,
  },
  {
    id: 'terremotos', name: 'Terremotos', icon: 'activity', color: '#ff7a33',
    summary: 'Acciones para reducir lesiones, evacuar estructuras y manejar escombros de forma técnica.',
    before: ['Asegura muebles y objetos pesados.', 'Identifica zonas de protección estructural.', 'Realiza simulacros familiares y comunitarios.', 'Ubica llaves de gas, agua y energía.'],
    during: ['Agáchate, cúbrete y sujétate.', 'Aléjate de ventanas y fachadas.', 'No uses ascensores.', 'Si estás afuera, busca un área despejada.'],
    after: ['Espera réplicas y revisa lesiones.', 'No ingreses a estructuras comprometidas.', 'Separa escombros reutilizables y peligrosos.', 'Mantén libres las rutas de emergencia.'],
    downloads: 9, videos: 5,
  },
  {
    id: 'sismos', name: 'Sismos', icon: 'pulse', color: '#f59e0b',
    summary: 'Guía rápida para movimientos sísmicos de distinta intensidad y sus réplicas.',
    before: ['Practica rutas cortas de evacuación.', 'Define un contacto fuera de la zona.', 'Mantén linterna y radio accesibles.', 'Revisa la estabilidad de estanterías.'],
    during: ['Conserva la calma y protégete.', 'No corras hacia escaleras durante el movimiento.', 'Cubre cabeza y cuello.', 'Sigue instrucciones de brigadistas.'],
    after: ['Verifica fugas y riesgos eléctricos.', 'Usa mensajes de texto para comunicarte.', 'Apoya el censo comunitario.', 'Reporta grietas y daños críticos.'],
    downloads: 6, videos: 3,
  },
  {
    id: 'volcanes', name: 'Volcanes', icon: 'mountain', color: '#ef5b3f',
    summary: 'Protección frente a ceniza, gases, lahares y evacuaciones preventivas.',
    before: ['Conoce zonas de amenaza y rutas señalizadas.', 'Ten gafas, mascarillas y agua almacenada.', 'Protege depósitos y cultivos.', 'Evita asentamientos en cauces de lahar.'],
    during: ['Evacúa según la autoridad competente.', 'Cubre nariz, boca y ojos.', 'Permanece bajo techo ante caída de ceniza.', 'No conduzcas salvo necesidad.'],
    after: ['Retira ceniza en húmedo y por capas.', 'No la arrojes a alcantarillas.', 'Revisa techos antes de acumularse peso.', 'Protege fuentes de agua y alimentos.'],
    downloads: 8, videos: 4,
  },
  {
    id: 'incendios', name: 'Incendios', icon: 'flame', color: '#f97316',
    summary: 'Prevención de incendios forestales, evacuación y restauración del suelo afectado.',
    before: ['Elimina material combustible cercano.', 'Reporta quemas no autorizadas.', 'Define puntos de encuentro.', 'Conserva franjas cortafuego donde corresponda.'],
    during: ['Evacúa en dirección contraria al humo.', 'Cubre nariz y boca con tela húmeda.', 'No intentes combatir un frente intenso.', 'Informa ubicación y dirección del fuego.'],
    after: ['Evita ingresar hasta autorización.', 'Controla erosión con barreras naturales.', 'No remuevas toda la cobertura quemada.', 'Apoya restauración con especies nativas.'],
    downloads: 10, videos: 6,
  },
  {
    id: 'deslizamientos', name: 'Deslizamientos', icon: 'landslide', color: '#8b6f47',
    summary: 'Identificación de señales, evacuación y estabilización ambiental de laderas.',
    before: ['Observa grietas, inclinación de árboles y filtraciones.', 'No cortes laderas sin estudio técnico.', 'Mantén drenajes limpios.', 'Evita sobrecargar bordes de taludes.'],
    during: ['Aléjate lateralmente de la trayectoria.', 'No cruces la masa en movimiento.', 'Advierte a vecinos sin exponerte.', 'Evacúa hacia terreno firme.'],
    after: ['No regreses por posibles movimientos secundarios.', 'Reporta tuberías rotas.', 'Clasifica suelo, vegetación y residuos.', 'Implementa revegetación y drenaje técnico.'],
    downloads: 8, videos: 4,
  },
  {
    id: 'vendavales', name: 'Vendavales', icon: 'wind', color: '#6d5bd0',
    summary: 'Reducción de daños por vientos fuertes y recuperación segura de cubiertas y vegetación.',
    before: ['Asegura techos, avisos y objetos sueltos.', 'Poda técnica de ramas inestables.', 'Identifica espacios interiores seguros.', 'Carga dispositivos y linternas.'],
    during: ['Aléjate de ventanas.', 'No te refugies bajo árboles o postes.', 'Desconecta equipos sensibles.', 'Espera información oficial antes de salir.'],
    after: ['Evita cables caídos.', 'Revisa cubiertas desde el suelo.', 'Separa madera, metales y residuos peligrosos.', 'Reporta bloqueos en rutas y cauces.'],
    downloads: 5, videos: 3,
  },
];

export const libraryItems: LibraryItem[] = [
  { id: 'd1', title: 'Guía comunitaria para manejo de escombros', category: 'Recuperación', type: 'PDF', size: '4.8 MB', updated: '18 jul 2026', description: 'Clasificación, almacenamiento temporal, reutilización y disposición segura.', downloads: 842 },
  { id: 'd2', title: 'Matriz de riesgos locales', category: 'Planeación', type: 'Excel', size: '1.2 MB', updated: '16 jul 2026', description: 'Plantilla editable para identificar amenazas, exposición y vulnerabilidad.', downloads: 524 },
  { id: 'd3', title: 'Presentación para simulacro comunitario', category: 'Educación', type: 'PowerPoint', size: '9.4 MB', updated: '12 jul 2026', description: 'Material visual para talleres, colegios y juntas de acción comunal.', downloads: 318 },
  { id: 'd4', title: 'Manual de protección de fuentes hídricas', category: 'Agua', type: 'Word', size: '2.7 MB', updated: '10 jul 2026', description: 'Acciones antes y después de emergencias para evitar contaminación.', downloads: 465 },
  { id: 'd5', title: 'Infografía: kit de emergencia 72 horas', category: 'Preparación', type: 'Imagen', size: '3.1 MB', updated: '7 jul 2026', description: 'Lista visual para familias y organizaciones comunitarias.', downloads: 1034 },
  { id: 'd6', title: 'Video: rutas seguras de evacuación', category: 'Evacuación', type: 'Video', size: '68 MB', updated: '4 jul 2026', description: 'Cómo definir, señalizar y practicar rutas de evacuación.', downloads: 239 },
];

export const courses: Course[] = [
  { id: 'c1', title: 'Primer respondiente comunitario', category: 'Emergencias', description: 'Fundamentos para apoyar sin exponerse y activar correctamente la cadena de respuesta.', duration: '6 h', lessons: 12, level: 'Básico', progress: 35, instructor: 'Equipo Kairós', modules: ['Gestión del riesgo', 'Evaluación inicial', 'Comunicación', 'Simulación final'] },
  { id: 'c2', title: 'Manejo ambiental de escombros', category: 'Recuperación', description: 'Clasifica, reutiliza y dispone residuos post-desastre protegiendo suelo y agua.', duration: '8 h', lessons: 16, level: 'Intermedio', progress: 0, instructor: 'Área técnica ambiental', modules: ['Tipos de residuos', 'Riesgos', 'Acopio temporal', 'Reutilización y disposición'] },
  { id: 'c3', title: 'Mapeo comunitario de riesgos', category: 'Mapas', description: 'Construye mapas participativos con puntos seguros, refugios y rutas de evacuación.', duration: '5 h', lessons: 10, level: 'Básico', progress: 68, instructor: 'Laboratorio territorial', modules: ['Lectura del territorio', 'Levantamiento de datos', 'Mapas', 'Socialización'] },
  { id: 'c4', title: 'Restauración ecológica post-emergencia', category: 'Ambiente', description: 'Principios de recuperación de suelos, cauces y coberturas vegetales con especies nativas.', duration: '10 h', lessons: 20, level: 'Avanzado', progress: 0, instructor: 'Red de restauración', modules: ['Diagnóstico', 'Control de erosión', 'Reforestación', 'Monitoreo'] },
];

export const news: NewsItem[] = [
  { id: 'n1', title: 'Comunidad realiza simulacro con enfoque ambiental', category: 'Comunidad', excerpt: 'Más de 180 personas practicaron evacuación, comunicación y clasificación inicial de residuos.', date: '20 jul 2026', readTime: '4 min', image: 'community' },
  { id: 'n2', title: 'Cinco señales tempranas de inestabilidad en laderas', category: 'Prevención', excerpt: 'Grietas nuevas, filtraciones y cambios en árboles pueden anticipar movimientos del terreno.', date: '18 jul 2026', readTime: '6 min', image: 'mountain' },
  { id: 'n3', title: 'Nueva guía para proteger quebradas después de una inundación', category: 'Recuperación', excerpt: 'El protocolo prioriza retiro selectivo, control de sedimentos y manejo de residuos peligrosos.', date: '15 jul 2026', readTime: '5 min', image: 'river' },
  { id: 'n4', title: 'Voluntariado abre jornada de reforestación', category: 'Eventos', excerpt: 'La actividad incluye formación, siembra de especies nativas y monitoreo comunitario.', date: '12 jul 2026', readTime: '3 min', image: 'forest' },
];

export const alerts: AlertItem[] = [
  { id: 'a1', title: 'Incremento de nivel en quebradas', location: 'Zona rural norte', severity: 'Alta', status: 'Activa', issued: 'Hace 18 min', recommendation: 'Evita cruces y permanece atento a instrucciones de evacuación preventiva.' },
  { id: 'a2', title: 'Lluvias intensas con posibilidad de deslizamientos', location: 'Corredor montañoso oriental', severity: 'Moderada', status: 'En seguimiento', issued: 'Hace 1 h', recommendation: 'Revisa drenajes, identifica grietas y no estaciones vehículos junto a taludes.' },
  { id: 'a3', title: 'Calidad del aire afectada por humo', location: 'Sector occidental', severity: 'Baja', status: 'En seguimiento', issued: 'Hace 3 h', recommendation: 'Limita actividades al aire libre si presentas sensibilidad respiratoria.' },
  { id: 'a4', title: 'Cierre preventivo de vía por caída de material', location: 'Ruta 07, km 14', severity: 'Crítica', status: 'Activa', issued: 'Hace 7 min', recommendation: 'Usa la ruta alterna señalizada y no intentes cruzar la zona acordonada.' },
];

export const posts: CommunityPost[] = [
  { id: 'p1', author: 'Laura Méndez', role: 'Voluntario', title: '¿Cómo organizamos un simulacro en el barrio?', body: 'Tenemos 60 familias y queremos iniciar con un ejercicio sencillo. ¿Qué roles recomiendan?', category: 'Simulacros', likes: 24, comments: 9, date: 'Hace 2 h' },
  { id: 'p2', author: 'Carlos Rojas', role: 'Instructor', title: 'Lista de chequeo para refugios temporales', body: 'Compartimos puntos clave sobre agua, accesibilidad, residuos, ventilación y registro de personas.', category: 'Refugios', likes: 41, comments: 12, date: 'Ayer' },
  { id: 'p3', author: 'Mariana Gil', role: 'Visitante', title: 'Jornada de limpieza de la quebrada', body: 'Buscamos voluntarios para separar residuos y documentar puntos críticos este sábado.', category: 'Voluntariado', likes: 36, comments: 17, date: 'Hace 2 días' },
];

export const stats = [
  { value: '24.800+', label: 'Personas alcanzadas' },
  { value: '68', label: 'Protocolos y guías' },
  { value: '31', label: 'Comunidades vinculadas' },
  { value: '92%', label: 'Satisfacción formativa' },
];
