import { Icon } from '../components/Icon';
import { SectionHeader } from '../components/UI';
import { protocols, stats, news } from '../data/seed';

export function Home({ navigate }: { navigate: (path: string) => void }) {
  return <>
    <section className="home-hero">
      <div className="hero-noise" />
      <div className="container home-hero-grid">
        <div className="hero-copy reveal">
          <span className="eyebrow light"><i /> Resiliencia comunitaria y ambiental</span>
          <h1>Actuar a tiempo<br />puede cambiarlo <em>todo.</em></h1>
          <p>KAIRÓS integra educación, protocolos técnicos, alertas y recuperación ambiental para proteger a las personas y al territorio antes, durante y después de una emergencia.</p>
          <div className="hero-actions">
            <button className="button large" onClick={() => navigate('/protocolos')}>Explorar plataforma <Icon name="arrow" /></button>
            <button className="button large glass" onClick={() => navigate('/protocolos')}><Icon name="shield" /> Ver protocolos</button>
            <button className="text-link light-link" onClick={() => navigate('/cursos')}>Aprender ahora <Icon name="chevron" size={17} /></button>
          </div>
          <div className="hero-trust">
            <div className="avatar-stack"><span>LM</span><span>CR</span><span>MG</span><span>+2k</span></div>
            <p><b>Comunidades preparadas</b><br /><span>Educación que se convierte en acción.</span></p>
          </div>
        </div>
        <div className="hero-visual" aria-label="Representación de gestión de emergencias">
          <div className="visual-glow" />
          <svg viewBox="0 0 680 620" role="img" aria-label="Territorio protegido ante amenazas naturales">
            <defs>
              <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0b5267"/><stop offset="1" stopColor="#072b38"/></linearGradient>
              <linearGradient id="land" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#2f8d67"/><stop offset="1" stopColor="#123e3a"/></linearGradient>
              <linearGradient id="water" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#42d7ef"/><stop offset="1" stopColor="#0a6b8d"/></linearGradient>
              <filter id="blur"><feGaussianBlur stdDeviation="14"/></filter>
            </defs>
            <circle cx="500" cy="105" r="62" fill="#ffd38c" opacity=".9" filter="url(#blur)" />
            <circle cx="500" cy="105" r="34" fill="#ffe0a8" />
            <path d="M0 355 150 210 250 310 370 150 520 318 680 205V620H0Z" fill="url(#sky)" opacity=".8"/>
            <path d="M0 420 130 312 230 380 350 235 485 392 590 310 680 380V620H0Z" fill="url(#land)"/>
            <path d="M0 445c120-40 208 65 325 12 100-45 195-15 355 40v123H0Z" fill="url(#water)" opacity=".8"/>
            <path d="M315 620c18-92 2-147-39-194-38-43-54-96-12-150 14 53 56 79 89 112 61 60 43 141 27 232Z" fill="#88e5f3" opacity=".75"/>
            <g fill="#daf7e9"><path d="M108 420l18-72 20 72Z"/><path d="M140 432l21-92 24 92Z"/><path d="M475 430l22-96 25 96Z"/><path d="M515 448l17-73 20 73Z"/></g>
            <g fill="#071f2b" opacity=".85"><rect x="190" y="407" width="72" height="55" rx="3"/><path d="m180 410 47-38 47 38Z"/><rect x="214" y="429" width="19" height="33" fill="#ffce7a"/></g>
            <g transform="translate(390 347)"><circle cx="54" cy="54" r="49" fill="#ffffff" opacity=".96"/><path d="M54 17c-20 7-31 22-31 39 0 26 31 42 31 42s31-16 31-42c0-17-11-32-31-39Z" fill="#15a7c2"/><path d="M40 56l10 10 22-27" fill="none" stroke="#fff" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/></g>
          </svg>
          <div className="floating-card card-alert"><span className="pulse-dot" /><div><small>ALERTA TEMPRANA</small><strong>Respuesta en curso</strong></div></div>
          <div className="floating-card card-air"><Icon name="leaf" /><div><small>RECUPERACIÓN</small><strong>Territorio sostenible</strong></div></div>
          <div className="floating-card card-map"><Icon name="map" /><div><small>MAPA LOCAL</small><strong>3 puntos seguros</strong></div></div>
        </div>
      </div>
      <div className="hero-wave" />
    </section>

    <section className="section about-preview">
      <div className="container split-grid">
        <div className="media-composition">
          <div className="media-card media-main"><div className="abstract-photo community-photo"><span className="people-group">● ● ●</span></div><div className="media-caption"><Icon name="users" /><span><b>Conocimiento compartido</b><small>La preparación comienza en comunidad</small></span></div></div>
          <div className="media-card media-small"><div className="abstract-photo water-photo" /></div>
          <div className="metric-chip"><strong>31</strong><span>comunidades<br />vinculadas</span></div>
        </div>
        <div>
          <SectionHeader eyebrow="¿Qué es KAIRÓS?" title="Una plataforma para el momento que importa." text="Kairós significa el momento oportuno: ese instante preciso en el que actuar con información correcta salva vidas y protege el entorno." />
          <div className="feature-lines">
            <div><span><Icon name="shield" /></span><p><b>Gestión integral</b><small>Conecta preparación, respuesta y recuperación sostenible.</small></p></div>
            <div><span><Icon name="book" /></span><p><b>Educación aplicada</b><small>Guías, cursos y simulacros pensados para el territorio.</small></p></div>
            <div><span><Icon name="leaf" /></span><p><b>Protección ambiental</b><small>Evita que los residuos post-desastre generen una segunda emergencia.</small></p></div>
          </div>
          <button className="button secondary" onClick={() => navigate('/nosotros')}>Conoce nuestra historia <Icon name="arrow" /></button>
        </div>
      </div>
    </section>

    <section className="section how-section">
      <div className="container">
        <SectionHeader eyebrow="Cómo funciona" title="Preparación para cada etapa." text="Un mismo sistema acompaña a las comunidades desde la prevención hasta la recuperación ecológica." align="center" />
        <div className="phase-grid">
          <article className="phase-card cyan"><span className="phase-number">01</span><div className="phase-icon"><Icon name="book" size={30} /></div><span className="phase-label">ANTES</span><h3>Prepárate</h3><p>Aprende, identifica riesgos, construye rutas y organiza tu plan comunitario.</p><button onClick={() => navigate('/cursos')}>Explorar formación <Icon name="arrow" size={17} /></button></article>
          <article className="phase-card orange"><span className="phase-number">02</span><div className="phase-icon"><Icon name="alert" size={30} /></div><span className="phase-label">DURANTE</span><h3>Actúa</h3><p>Consulta alertas, protocolos de respuesta y puntos seguros en tiempo real.</p><button onClick={() => navigate('/alertas')}>Consultar alertas <Icon name="arrow" size={17} /></button></article>
          <article className="phase-card green"><span className="phase-number">03</span><div className="phase-icon"><Icon name="leaf" size={30} /></div><span className="phase-label">DESPUÉS</span><h3>Recupera</h3><p>Gestiona residuos, restaura ecosistemas y fortalece la resiliencia territorial.</p><button onClick={() => navigate('/recuperacion')}>Ver recuperación <Icon name="arrow" size={17} /></button></article>
        </div>
      </div>
    </section>

    <section className="section protocols-preview">
      <div className="container">
        <div className="section-heading-row"><SectionHeader eyebrow="Protocolos técnicos" title="Información clara cuando cada segundo cuenta." text="Acciones verificables antes, durante y después de siete amenazas prioritarias." /><button className="button ghost" onClick={() => navigate('/protocolos')}>Ver todos <Icon name="arrow" /></button></div>
        <div className="protocol-mini-grid">
          {protocols.slice(0, 7).map(p => <button key={p.id} className="protocol-mini" onClick={() => navigate(`/protocolos#${p.id}`)}><span className="protocol-mini-icon" style={{ '--accent': p.color } as React.CSSProperties}><Icon name={p.icon} size={28} /></span><b>{p.name}</b><small>Guía completa</small><Icon name="chevron" className="mini-arrow" /></button>)}
        </div>
      </div>
    </section>

    <section className="stats-band">
      <div className="container stats-grid">{stats.map(s => <div key={s.label}><strong>{s.value}</strong><span>{s.label}</span></div>)}</div>
    </section>

    <section className="section video-section">
      <div className="container video-card">
        <div className="video-art"><div className="video-rings" /><button aria-label="Reproducir video"><Icon name="play" size={40} /></button><span>02:18</span></div>
        <div><span className="eyebrow">Conoce el proyecto</span><h2>Una emergencia no termina cuando pasa el peligro.</h2><p>La recuperación ambiental es parte de la respuesta. Descubre cómo KAIRÓS transforma el conocimiento técnico en acción comunitaria.</p><button className="button" onClick={() => navigate('/nosotros')}>Descubrir KAIRÓS <Icon name="arrow" /></button></div>
      </div>
    </section>

    <section className="section testimonials-section">
      <div className="container"><SectionHeader eyebrow="Impacto real" title="Voces de una comunidad que se prepara." align="center" />
        <div className="testimonial-grid">
          <blockquote><div className="quote-mark">“</div><p>Antes teníamos una lista de teléfonos. Ahora entendemos las rutas, los roles y cómo proteger la quebrada después de una emergencia.</p><footer><span>AM</span><div><b>Ana Martínez</b><small>Líder comunitaria</small></div></footer></blockquote>
          <blockquote><div className="quote-mark">“</div><p>Los protocolos son muy claros. El enfoque ambiental marca la diferencia porque la recuperación no puede improvisarse.</p><footer><span>JR</span><div><b>Julián Ríos</b><small>Brigadista voluntario</small></div></footer></blockquote>
          <blockquote><div className="quote-mark">“</div><p>La plataforma permite enseñar con ejemplos, documentos y ejercicios. Es una herramienta pensada para aprender haciendo.</p><footer><span>SP</span><div><b>Sandra Peña</b><small>Instructora ambiental</small></div></footer></blockquote>
        </div>
      </div>
    </section>

    <section className="section news-preview">
      <div className="container"><div className="section-heading-row"><SectionHeader eyebrow="Actualidad" title="Noticias para entender y actuar." /><button className="text-link" onClick={() => navigate('/noticias')}>Todas las noticias <Icon name="arrow" /></button></div>
        <div className="news-grid">{news.slice(0, 3).map((n, i) => <article className="news-card" key={n.id}><div className={`news-image image-${n.image}`}><span>{n.category}</span></div><div className="news-body"><small>{n.date} · {n.readTime}</small><h3>{n.title}</h3><p>{n.excerpt}</p><button onClick={() => navigate('/noticias')}>Leer artículo <Icon name="arrow" size={17} /></button></div></article>)}</div>
      </div>
    </section>

    <section className="section allies-section"><div className="container"><span className="eyebrow centered">Aliados para la resiliencia</span><div className="ally-row"><span>COMUNIDADES</span><span>ACADEMIA</span><span>AMBIENTE</span><span>TECNOLOGÍA</span><span>TERRITORIO</span></div></div></section>

    <section className="section faq-section"><div className="container faq-grid"><div><SectionHeader eyebrow="Preguntas frecuentes" title="Respuestas para comenzar." text="Encuentra información sobre el uso de la plataforma, los protocolos y la participación comunitaria." /><button className="button ghost" onClick={() => navigate('/contacto')}>Hablar con el equipo</button></div><div className="faq-list">
      {[
        ['¿La plataforma reemplaza a las autoridades?', 'No. KAIRÓS complementa la información oficial con educación, organización comunitaria y recuperación ambiental.'],
        ['¿Puedo descargar las guías?', 'Sí. La biblioteca admite documentos, presentaciones, videos e infografías organizados por categorías.'],
        ['¿Cómo participa una comunidad?', 'Puede solicitar un taller, registrar voluntarios, publicar eventos o preparar un simulacro desde la plataforma.'],
        ['¿Los datos de alertas son reales?', 'En este prototipo son datos de demostración. La arquitectura está preparada para integrar fuentes oficiales.'],
      ].map(([q, a], i) => <details key={q} open={i === 0}><summary>{q}<span>+</span></summary><p>{a}</p></details>)}</div></div></section>

    <section className="cta-section"><div className="cta-orb"/><div className="container cta-content"><span className="eyebrow light">El momento es ahora</span><h2>Una comunidad preparada<br />es una comunidad más fuerte.</h2><p>Explora la plataforma, aprende y convierte el conocimiento en acción.</p><div><button className="button large white" onClick={() => navigate('/registro')}>Crear una cuenta <Icon name="arrow" /></button><button className="button large glass" onClick={() => navigate('/contacto')}>Contactar al equipo</button></div></div></section>
  </>;
}
