import { useState } from 'react';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/UI';
import { news } from '../data/seed';

export function News() {
  const [query,setQuery]=useState(''); const [category,setCategory]=useState('Todas');
  const categories=['Todas',...new Set(news.map(x=>x.category))];
  const filtered=news.filter(n=>(category==='Todas'||n.category===category)&&`${n.title} ${n.excerpt}`.toLowerCase().includes(query.toLowerCase()));
  return <>
    <PageHero eyebrow="Noticias y análisis" title="Información para comprender el territorio." text="Actualidad, prevención, experiencias comunitarias y recuperación ambiental en un solo lugar." />
    <section className="section news-page"><div className="container"><div className="news-toolbar"><div className="library-search"><Icon name="search"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Buscar noticias..."/></div><div className="category-tabs">{categories.map(c=><button key={c} className={c===category?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div></div>
      {filtered[0]&&<article className="featured-news"><div className={`featured-image image-${filtered[0].image}`}><span>DESTACADO</span></div><div><span className="eyebrow">{filtered[0].category}</span><h2>{filtered[0].title}</h2><p>{filtered[0].excerpt} Conoce las recomendaciones, la metodología y los resultados que pueden ser replicados en otros territorios.</p><div className="article-meta"><span>{filtered[0].date}</span><i/><span>{filtered[0].readTime} de lectura</span></div><button className="button">Leer noticia <Icon name="arrow"/></button></div></article>}
      <div className="news-list-grid">{filtered.slice(1).map(n=><article className="news-card horizontal" key={n.id}><div className={`news-image image-${n.image}`}><span>{n.category}</span></div><div className="news-body"><small>{n.date} · {n.readTime}</small><h3>{n.title}</h3><p>{n.excerpt}</p><button>Leer artículo <Icon name="arrow" size={17}/></button></div></article>)}</div>
      <div className="newsletter"><span><Icon name="mail" size={30}/></span><div><h3>Recibe el boletín KAIRÓS</h3><p>Alertas educativas, nuevas guías y convocatorias directamente en tu correo.</p></div><form onSubmit={e=>e.preventDefault()}><input type="email" placeholder="tu@correo.com" required/><button className="button">Suscribirme</button></form></div>
    </div></section>
  </>;
}
