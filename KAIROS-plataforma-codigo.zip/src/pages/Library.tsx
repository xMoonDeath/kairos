import { useMemo, useState } from 'react';
import { Icon } from '../components/Icon';
import { EmptyState, PageHero, Toast } from '../components/UI';
import { libraryItems } from '../data/seed';
import { useLocalStorage } from '../hooks/useLocalStorage';

export function Library() {
  const [query,setQuery]=useState(''); const [category,setCategory]=useState('Todas'); const [type,setType]=useState('Todos'); const [sort,setSort]=useState('Recientes');
  const [favorites,setFavorites]=useLocalStorage<string[]>('kairos-favorites',[]); const [toast,setToast]=useState('');
  const categories=['Todas',...new Set(libraryItems.map(x=>x.category))]; const types=['Todos',...new Set(libraryItems.map(x=>x.type))];
  const filtered=useMemo(()=>libraryItems.filter(x=>(category==='Todas'||x.category===category)&&(type==='Todos'||x.type===type)&&`${x.title} ${x.description}`.toLowerCase().includes(query.toLowerCase())).sort((a,b)=>sort==='Más descargados'?b.downloads-a.downloads:a.id.localeCompare(b.id)),[query,category,type,sort]);
  const toggle=(id:string)=>setFavorites(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id]);
  const download=(title:string)=>{setToast(`Descarga de demostración: ${title}`);setTimeout(()=>setToast(''),2600)};
  return <>
    <PageHero eyebrow="Centro de conocimiento" title="Biblioteca técnica y multimedia." text="Guías, manuales, plantillas, infografías y videos organizados para aprender y actuar." />
    <section className="section library-section"><div className="container"><div className="library-toolbar"><div className="library-search"><Icon name="search"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Buscar por título, tema o palabra clave..."/></div><button className="button"><Icon name="upload"/> Subir recurso</button></div>
      <div className="library-filters"><div><Icon name="filter" size={18}/><span>Filtrar por</span></div><select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select><select value={type} onChange={e=>setType(e.target.value)}>{types.map(x=><option key={x}>{x}</option>)}</select><select value={sort} onChange={e=>setSort(e.target.value)}><option>Recientes</option><option>Más descargados</option></select><span className="result-count">{filtered.length} recursos</span></div>
      {filtered.length?<div className="library-grid">{filtered.map(item=><article className="library-card" key={item.id}><div className={`file-cover type-${item.type.toLowerCase()}`}><Icon name={item.type==='Video'?'play':item.type==='Imagen'?'map':'file'} size={34}/><b>{item.type}</b><span>{item.category}</span></div><div className="library-card-body"><div className="file-meta"><span>{item.type}</span><small>{item.size}</small></div><h3>{item.title}</h3><p>{item.description}</p><div className="file-stats"><span><Icon name="download" size={15}/>{item.downloads}</span><span>Actualizado {item.updated}</span></div><div className="file-actions"><button className="button small secondary" onClick={()=>download(item.title)}><Icon name="download" size={17}/> Descargar</button><button className={`icon-button ${favorites.includes(item.id)?'favorite':''}`} onClick={()=>toggle(item.id)} aria-label="Favorito"><Icon name={favorites.includes(item.id)?'heartFill':'heart'}/></button></div></div></article>)}</div>:<EmptyState icon="file" title="No encontramos recursos" text="Cambia los filtros o prueba otra búsqueda."/>}
      <div className="upload-callout"><div><span><Icon name="upload" size={28}/></span><div><h3>Repositorio preparado para crecer</h3><p>Admite PDF, Word, Excel, PowerPoint, imágenes y videos con categorías, permisos y metadatos.</p></div></div><button className="button ghost">Administrar biblioteca</button></div>
    </div></section>{toast&&<Toast message={toast}/>}</>;
}
