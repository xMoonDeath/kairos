import { useEffect, useState } from 'react';
import { Icon } from '../components/Icon';
import { EmptyState, PageHero } from '../components/UI';
import { protocols } from '../data/seed';

export function Protocols() {
  const hashId = window.location.hash.includes('#/protocolos#') ? window.location.hash.split('#/protocolos#')[1] : '';
  const [selected, setSelected] = useState(hashId || protocols[0].id);
  const [phase, setPhase] = useState<'before'|'during'|'after'>('before');
  const [query, setQuery] = useState('');
  useEffect(() => { if (hashId) setSelected(hashId); }, [hashId]);
  const filtered = protocols.filter(p => p.name.toLowerCase().includes(query.toLowerCase()));
  const current = protocols.find(p => p.id === selected) || protocols[0];
  const phaseCopy = { before: ['Antes del evento', current.before], during: ['Durante el evento', current.during], after: ['Después del evento', current.after] } as const;

  return <>
    <PageHero eyebrow="Protocolos técnicos" title="Saber qué hacer reduce el riesgo." text="Consulta instrucciones claras para prepararte, responder y recuperar el entorno ante diferentes amenazas naturales.">
      <div className="hero-search"><Icon name="search"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Buscar un protocolo..."/></div>
    </PageHero>
    <section className="section protocol-workspace"><div className="container protocol-layout">
      <aside className="protocol-sidebar"><span>AMENAZAS</span>{filtered.length ? filtered.map(p => <button key={p.id} className={p.id===current.id?'active':''} onClick={()=>{setSelected(p.id); history.replaceState(null,'',`#/protocolos#${p.id}`)}}><i style={{background:p.color}}><Icon name={p.icon}/></i><span><b>{p.name}</b><small>{p.downloads} recursos</small></span><Icon name="chevron" size={16}/></button>) : <EmptyState title="Sin resultados" text="Prueba con otro término."/>}</aside>
      <div className="protocol-content">
        <div className="protocol-title"><span className="large-hazard-icon" style={{'--accent':current.color} as React.CSSProperties}><Icon name={current.icon} size={36}/></span><div><span>PROTOCOLO</span><h2>{current.name}</h2><p>{current.summary}</p></div><button className="button ghost"><Icon name="download"/> Descargar PDF</button></div>
        <div className="phase-tabs"><button className={phase==='before'?'active':''} onClick={()=>setPhase('before')}><span>01</span> Antes</button><button className={phase==='during'?'active':''} onClick={()=>setPhase('during')}><span>02</span> Durante</button><button className={phase==='after'?'active':''} onClick={()=>setPhase('after')}><span>03</span> Después</button></div>
        <div className="phase-panel"><div className={`phase-banner ${phase}`}><Icon name={phase==='before'?'book':phase==='during'?'alert':'leaf'} size={28}/><div><span>{phaseCopy[phase][0]}</span><h3>{phase==='before'?'Prepárate con anticipación':phase==='during'?'Protege tu vida y sigue instrucciones':'Recupera de forma segura y sostenible'}</h3></div></div><ol>{phaseCopy[phase][1].map((item,i)=><li key={item}><span>{String(i+1).padStart(2,'0')}</span><p>{item}</p><Icon name="check"/></li>)}</ol></div>
        <div className="resource-heading"><h3>Material complementario</h3><span>{current.downloads + current.videos} recursos</span></div>
        <div className="resource-grid"><article><span className="resource-icon pdf"><Icon name="file"/></span><div><b>Guía técnica descargable</b><small>PDF · 4.2 MB</small></div><button><Icon name="download"/></button></article><article><span className="resource-icon video"><Icon name="play"/></span><div><b>Video explicativo</b><small>6 minutos · HD</small></div><button><Icon name="play"/></button></article><article><span className="resource-icon image"><Icon name="map"/></span><div><b>Infografía comunitaria</b><small>PNG · Alta resolución</small></div><button><Icon name="download"/></button></article></div>
        <div className="official-note"><Icon name="shield"/><p><b>Información complementaria.</b> En una emergencia real, sigue siempre las instrucciones de las autoridades y organismos de socorro de tu territorio.</p></div>
      </div>
    </div></section>
  </>;
}
