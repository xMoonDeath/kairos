import { useState } from 'react';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/UI';
import { alerts } from '../data/seed';

const severityClass: Record<string,string>={Baja:'low',Moderada:'medium',Alta:'high','Crítica':'critical'};
export function Alerts() {
  const [scope,setScope]=useState('Todas');
  const filtered=scope==='Todas'?alerts:alerts.filter(a=>a.severity===scope);
  return <>
    <PageHero eyebrow="Centro de alertas" title="Información visible. Decisiones oportunas." text="Consulta avisos oficiales y locales, recomendaciones y zonas afectadas. Los datos actuales son demostrativos."><button className="button large"><Icon name="bell"/> Activar notificaciones</button></PageHero>
    <section className="alert-dashboard"><div className="container"><div className="alert-summary"><div className="summary-status"><span className="status-pulse"/><div><small>ESTADO GENERAL</small><strong>Monitoreo preventivo</strong></div></div><div><b>2</b><span>Alertas activas</span></div><div><b>3</b><span>Zonas observadas</span></div><div><b>20:14</b><span>Última actualización</span></div></div></div></section>
    <section className="section"><div className="container alerts-layout"><div className="alerts-column"><div className="section-heading-row compact"><div><span className="eyebrow">Avisos actuales</span><h2>Alertas y recomendaciones</h2></div><select value={scope} onChange={e=>setScope(e.target.value)}><option>Todas</option><option>Crítica</option><option>Alta</option><option>Moderada</option><option>Baja</option></select></div>
      <div className="alerts-list">{filtered.map(a=><article className={`alert-card ${severityClass[a.severity]}`} key={a.id}><div className="alert-card-top"><span className="severity-icon"><Icon name="alert"/></span><div><span>{a.severity.toUpperCase()}</span><h3>{a.title}</h3><p><Icon name="location" size={15}/>{a.location}</p></div><small>{a.issued}</small></div><div className="alert-recommendation"><b>Recomendación</b><p>{a.recommendation}</p></div><div className="alert-card-footer"><span className={`status-chip ${a.status==='Activa'?'active':''}`}>{a.status}</span><button>Ver detalles <Icon name="arrow" size={17}/></button></div></article>)}</div></div>
      <aside className="alerts-map"><div className="map-header"><div><span className="eyebrow">Mapa operativo</span><h3>Zonas afectadas</h3></div><button className="icon-button"><Icon name="settings"/></button></div><div className="mini-map"><div className="map-grid-lines"/><div className="river-shape"/><span className="map-marker m1 critical"><i/>Ruta 07</span><span className="map-marker m2 high"><i/>Zona norte</span><span className="map-marker m3 medium"><i/>Corredor oriental</span><div className="map-controls"><button>+</button><button>−</button></div></div><div className="map-legend"><span><i className="critical"/>Crítica</span><span><i className="high"/>Alta</span><span><i className="medium"/>Moderada</span></div><div className="demo-warning"><Icon name="alert"/><p><b>Datos de demostración</b><small>La versión productiva debe conectarse a fuentes oficiales y sistemas locales.</small></p></div></aside>
    </div></section>
  </>;
}
