import { useEffect, useState } from 'react';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Protocols } from './pages/Protocols';
import { Library } from './pages/Library';
import { Courses } from './pages/Courses';
import { News } from './pages/News';
import { Alerts } from './pages/Alerts';
import { Maps } from './pages/Maps';
import { Recovery } from './pages/Recovery';
import { Community } from './pages/Community';
import { Contact } from './pages/Contact';
import { Admin } from './pages/Admin';
import { Auth } from './pages/Auth';
import { Icon } from './components/Icon';

function normalizeHash() {
  const raw = window.location.hash.replace(/^#/, '') || '/';
  return raw.startsWith('/') ? raw.split('#')[0] : `/${raw.split('#')[0]}`;
}

export default function App() {
  const [path, setPath] = useState(normalizeHash);
  useEffect(() => {
    const update = () => { setPath(normalizeHash()); window.scrollTo({ top: 0, behavior: 'smooth' }); };
    window.addEventListener('hashchange', update);
    return () => window.removeEventListener('hashchange', update);
  }, []);
  const navigate = (next: string) => {
    const [route, anchor] = next.split('#');
    window.location.hash = anchor ? `${route}#${anchor}` : route;
    setPath(route);
  };

  if (path === '/admin') return <Admin />;
  if (path === '/login') return <Auth mode="login" navigate={navigate} />;
  if (path === '/registro') return <Auth mode="register" navigate={navigate} />;

  const pages: Record<string, JSX.Element> = {
    '/': <Home navigate={navigate} />,
    '/nosotros': <About navigate={navigate} />,
    '/protocolos': <Protocols />,
    '/biblioteca': <Library />,
    '/cursos': <Courses />,
    '/noticias': <News />,
    '/alertas': <Alerts />,
    '/mapas': <Maps />,
    '/recuperacion': <Recovery />,
    '/comunidad': <Community />,
    '/contacto': <Contact />,
  };

  const content = pages[path] ?? <section className="not-found"><img src="./kairos-mark.svg" alt=""/><span>404</span><h1>Esta ruta aún no existe.</h1><p>El territorio cambia, pero siempre podemos volver al punto seguro.</p><button className="button" onClick={() => navigate('/')}>Volver al inicio <Icon name="arrow"/></button></section>;
  return <Layout path={path} navigate={navigate}>{content}</Layout>;
}
