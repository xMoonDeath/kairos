import type { ReactNode } from 'react';
import { Icon } from './Icon';

export function SectionHeader({ eyebrow, title, text, align = 'left' }: { eyebrow?: string; title: string; text?: string; align?: 'left' | 'center' }) {
  return <div className={`section-header ${align === 'center' ? 'center' : ''}`}>
    {eyebrow && <span className="eyebrow">{eyebrow}</span>}
    <h2>{title}</h2>
    {text && <p>{text}</p>}
  </div>;
}

export function PageHero({ eyebrow, title, text, children }: { eyebrow: string; title: string; text: string; children?: ReactNode }) {
  return <section className="page-hero">
    <div className="container page-hero-grid">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p>{text}</p>
        {children && <div className="hero-actions">{children}</div>}
      </div>
      <div className="page-orbit" aria-hidden="true">
        <span className="orbit orbit-a" />
        <span className="orbit orbit-b" />
        <img src="./kairos-mark.svg" alt="" />
      </div>
    </div>
  </section>;
}

export function EmptyState({ icon = 'search', title, text }: { icon?: string; title: string; text: string }) {
  return <div className="empty-state"><span className="icon-box"><Icon name={icon} size={28} /></span><h3>{title}</h3><p>{text}</p></div>;
}

export function Modal({ open, title, onClose, children }: { open: boolean; title: string; onClose: () => void; children: ReactNode }) {
  if (!open) return null;
  return <div className="modal-backdrop" role="dialog" aria-modal="true" onMouseDown={onClose}>
    <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
      <div className="modal-head"><h3>{title}</h3><button className="icon-button" onClick={onClose} aria-label="Cerrar"><Icon name="close" /></button></div>
      {children}
    </div>
  </div>;
}

export function Toast({ message }: { message: string }) {
  return <div className="toast"><Icon name="check" size={18} />{message}</div>;
}
