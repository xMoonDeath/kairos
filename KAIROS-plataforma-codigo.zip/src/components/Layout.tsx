import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Icon } from './Icon';
import { alerts, courses, libraryItems, news, protocols } from '../data/seed';

type Navigate = (path: string) => void;

const primary = [
  ['Inicio', '/'], ['Nosotros', '/nosotros'], ['Protocolos', '/protocolos'], ['Biblioteca', '/biblioteca'],
  ['Cursos', '/cursos'], ['Mapas', '/mapas'], ['Noticias', '/noticias'], ['Alertas', '/alertas'],
];
const more = [
  ['Comunidad', '/comunidad'], ['Recuperación Ambiental', '/recuperacion'], ['Panel Administrativo', '/admin'], ['Contacto', '/contacto'],
];

export function Layout({ children, path, navigate }: { children: ReactNode; path: string; navigate: Navigate }) {
  const [menu, setMenu] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [theme, setTheme] = useState(() => localStorage.getItem('kairos-theme') || 'light');

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('kairos-theme', theme);
  }, [theme]);
  useEffect(() => setMenu(false), [path]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setSearchOpen(true); }
      if (e.key === 'Escape') { setSearchOpen(false); setMenu(false); setMoreOpen(false); setNotificationsOpen(false); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const searchIndex = useMemo(() => [
    ...protocols.map(x => ({ title: x.name, meta: 'Protocolo', path: `/protocolos#${x.id}` })),
    ...libraryItems.map(x => ({ title: x.title, meta: `Biblioteca · ${x.type}`, path: '/biblioteca' })),
    ...courses.map(x => ({ title: x.title, meta: 'Curso', path: '/cursos' })),
    ...news.map(x => ({ title: x.title, meta: `Noticia · ${x.category}`, path: '/noticias' })),
    ...alerts.map(x => ({ title: x.title, meta: `Alerta · ${x.location}`, path: '/alertas' })),
  ], []);
  const results = query.trim() ? searchIndex.filter(x => `${x.title} ${x.meta}`.toLowerCase().includes(query.toLowerCase())).slice(0, 8) : searchIndex.slice(0, 6);

  const go = (p: string) => { navigate(p); setSearchOpen(false); setQuery(''); };
  return <>
    <div className="alert-strip"><Icon name="alert" size={16} /><span><strong>Centro de alertas:</strong> hay 2 avisos activos de demostración.</span><button onClick={() => navigate('/alertas')}>Consultar</button></div>
    <header className="topbar">
      <div className="container nav-wrap">
        <button className="brand" onClick={() => navigate('/')} aria-label="Ir al inicio">
          <img src="./kairos-mark.svg" alt="" /><span>KAIRÓS<small>Gestión integral</small></span>
        </button>
        <nav className="desktop-nav" aria-label="Navegación principal">
          {primary.map(([label, href]) => <button key={href} className={path === href ? 'active' : ''} onClick={() => navigate(href)}>{label}</button>)}
          <div className="nav-more">
            <button className={more.some(([, href]) => path === href) ? 'active' : ''} onClick={() => setMoreOpen(v => !v)}>Más <span>⌄</span></button>
            {moreOpen && <div className="nav-popover">
              {more.map(([label, href]) => <button key={href} onClick={() => { navigate(href); setMoreOpen(false); }}>{label}</button>)}
            </div>}
          </div>
        </nav>
        <div className="nav-actions">
          <button className="search-button" onClick={() => setSearchOpen(true)}><Icon name="search" /><span>Buscar</span><kbd>Ctrl K</kbd></button>
          <button className="icon-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Cambiar tema"><Icon name={theme === 'dark' ? 'sun' : 'moon'} /></button>
          <div className="notification-wrap">
            <button className="icon-button dot" onClick={() => setNotificationsOpen(v => !v)} aria-label="Notificaciones"><Icon name="bell" /></button>
            {notificationsOpen && <div className="notification-panel">
              <div className="panel-title"><strong>Notificaciones</strong><span>3 nuevas</span></div>
              <button onClick={() => navigate('/alertas')}><span className="notif-icon danger"><Icon name="alert" size={17} /></span><span><b>Alerta de quebradas</b><small>Actualizada hace 18 minutos</small></span></button>
              <button onClick={() => navigate('/cursos')}><span className="notif-icon"><Icon name="book" size={17} /></span><span><b>Continúa tu curso</b><small>Vas en 35% del progreso</small></span></button>
              <button onClick={() => navigate('/comunidad')}><span className="notif-icon green"><Icon name="users" size={17} /></span><span><b>Nuevo simulacro</b><small>Inscripciones abiertas</small></span></button>
            </div>}
          </div>
          <button className="button small ghost login" onClick={() => navigate('/login')}>Ingresar</button>
          <button className="button small" onClick={() => navigate('/registro')}>Registrarse</button>
          <button className="icon-button mobile-menu" onClick={() => setMenu(v => !v)} aria-label="Menú"><Icon name={menu ? 'close' : 'menu'} /></button>
        </div>
      </div>
      {menu && <div className="mobile-nav">
        {[...primary, ...more].map(([label, href]) => <button key={href} className={path === href ? 'active' : ''} onClick={() => navigate(href)}>{label}<Icon name="chevron" size={16} /></button>)}
        <div className="mobile-auth"><button className="button ghost" onClick={() => navigate('/login')}>Iniciar sesión</button><button className="button" onClick={() => navigate('/registro')}>Registrarse</button></div>
      </div>}
    </header>
    <main>{children}</main>
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand"><button className="brand inverse" onClick={() => navigate('/')}><img src="./kairos-mark.svg" alt="" /><span>KAIRÓS<small>Tu momento, tu acción, tu entorno.</small></span></button><p>Educación, tecnología y recuperación ambiental para comunidades más seguras y resilientes.</p><div className="socials"><button aria-label="Red social">in</button><button aria-label="Red social">f</button><button aria-label="Red social">▶</button><button aria-label="Red social">◎</button></div></div>
        <div><h4>Plataforma</h4><button onClick={() => navigate('/protocolos')}>Protocolos</button><button onClick={() => navigate('/biblioteca')}>Biblioteca</button><button onClick={() => navigate('/cursos')}>Cursos</button><button onClick={() => navigate('/mapas')}>Mapas</button></div>
        <div><h4>Participa</h4><button onClick={() => navigate('/comunidad')}>Comunidad</button><button onClick={() => navigate('/recuperacion')}>Recuperación ambiental</button><button onClick={() => navigate('/contacto')}>Voluntariado</button><button onClick={() => navigate('/noticias')}>Noticias</button></div>
        <div><h4>Contacto</h4><p><Icon name="mail" size={16} /> contacto@kairos.org</p><p><Icon name="location" size={16} /> Colombia</p><p><Icon name="globe" size={16} /> Atención comunitaria</p><button className="button small orange" onClick={() => navigate('/alertas')}>Ver alertas</button></div>
      </div>
      <div className="container footer-bottom"><span>© 2026 KAIRÓS. Prototipo académico y tecnológico.</span><span>Privacidad · Términos · Accesibilidad</span></div>
    </footer>

    {searchOpen && <div className="command-backdrop" onMouseDown={() => setSearchOpen(false)}>
      <div className="command" onMouseDown={e => e.stopPropagation()}>
        <div className="command-input"><Icon name="search" /><input autoFocus value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar protocolos, cursos, guías, noticias..." /><kbd>ESC</kbd></div>
        <div className="command-results">
          <small>{query ? `${results.length} resultados` : 'Sugerencias'}</small>
          {results.map((r, i) => <button key={`${r.path}-${i}`} onClick={() => go(r.path)}><span className="result-icon"><Icon name={r.meta.includes('Curso') ? 'book' : r.meta.includes('Alerta') ? 'alert' : r.meta.includes('Biblioteca') ? 'file' : 'search'} /></span><span><b>{r.title}</b><small>{r.meta}</small></span><Icon name="arrow" size={17} /></button>)}
        </div>
      </div>
    </div>}
  </>;
}
